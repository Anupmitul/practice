

export function AboutTemplate(){

    return(
        <div className="container-fluid">
            <div className="display">
            <div className="card mt-2 " >
                <h2>About Our Car Service</h2>
                <div className="card-body">
                    <h5 className="card-title"> Dolor sit amet, consectetur adipiscing elit,</h5>
                    <p className="card-text">
                    dolor sit amet, consectetur adipiscing elit,
                    sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. 
                    Ut enim ad minim veniam, quis nostrud dolor sit amet, consectetur adipiscing elit, 
                    sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. 
                    Ut enim ad minim veniam, quis nostrud dolor sit amet, consectetur 
                    adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore 
                    magna aliqua. Ut enim ad minim veniam, quis nostrud dolor sit amet, 
                    consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore 
                    et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud
                    </p>
                    <button>Read More</button>
                </div>
            </div>
            </div>
        </div>
    )
}